import React from "react";
import { AiOutlineLike } from "react-icons/ai";
import { BiComment } from "react-icons/bi";
import { Link } from "react-router-dom";
import Comments from "./Comments";
import TimeAgo from "./TimeAgo";
import Title from "./Title";

function SingleBlogCard({ blog }) {
  console.log(blog);
  const { image, title, description, createdAt, likes, comments, tags, user } =
    blog;

  console.log(blog);
  return (
    <>
      <div className="bg-white shadow">
        <img
          className="w-100"
          src={`${process.env.REACT_APP_PROXY}/files/${image}`}
          alt="blog"
        />
        <div className="p-3">
          <h4 className="text-center mt-4">{title}</h4>
          <p className="text-center">
            <TimeAgo timeStamp={createdAt} />
            <span className="mx-2">-</span>

            <span>
              {new Date(createdAt).getDate()}/{new Date(createdAt).getMonth()}/
              {new Date(createdAt).getFullYear()}
            </span>
            <span className="mx-2">-</span>
            <span className="me-1">
              <AiOutlineLike />
            </span>
            <span>{likes.length}</span>
            <span className="mx-2">-</span>
            <span className="me-1">
              <BiComment />
            </span>
            {comments && <span>{comments.length}</span>}
          </p>
          <p className="mt-4">{description}</p>
          <div className="text-center">
            {!tags.length > 0 && (
              <>
                <h6>Categorized in:</h6>
                <ul>
                  {tags.map((tag) => (
                    <li>
                      <Link to={`/blogs?hashlink=lifestyle`}>{tag}</Link>
                    </li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </div>
      </div>
      <div className="p-3 mt-4 shadow bg-white">
        <Title name="Comments" />
        {comments && comments.length > 0 ? (
          comments.map((comment, index) => (
            <Comments key={index} comment={comment} />
          ))
        ) : (
          <p>No Search Comments</p>
        )}
      </div>
    </>
  );
}

export default SingleBlogCard;
