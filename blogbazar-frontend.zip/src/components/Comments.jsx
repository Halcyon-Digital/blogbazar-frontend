import React from "react";

function Comments({ comment }) {
  return <div>Comments</div>;
}

export default Comments;
