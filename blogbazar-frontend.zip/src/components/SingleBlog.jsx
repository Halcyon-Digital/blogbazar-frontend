import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import { useQuery } from "react-query";
import { useParams } from "react-router-dom";
import { getBlogById } from "../api/api";
import Sidebar from "./Sidebar";
import SingleBlogCard from "./SingleBlogCard";

function SingleBlog() {
  const { blogId } = useParams();
  const { data, isLoading } = useQuery("d", () => getBlogById(blogId));

  return (
    <section className="pt-5">
      <Container>
        <Row>
          <Col lg={8}>
            {isLoading ? <h3>Loading ...</h3> : <SingleBlogCard blog={data} />}
          </Col>
          <Col lg={4}>
            <Sidebar />
          </Col>
        </Row>
      </Container>
    </section>
  );
}

export default SingleBlog;
