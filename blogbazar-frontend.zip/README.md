### Feature

1. Header
2. Menubar
3. Blog
4. Search
5. Recent Post blog
6. Create,update,delete self post Post
7. Authentication (login & register)
8. social Link
9. Taq
10. BlogBazar info.

### Technology use

# react

# sass

# react-router-dom

# marquee

# React Layout

# React Icon
